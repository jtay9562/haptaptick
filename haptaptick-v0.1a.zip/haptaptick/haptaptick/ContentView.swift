//
//  ContentView.swift
//  haptaptick
//
//  Created by Joshua Taylor on 4/19/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "hands.and.sparkles.fill")
                .padding(/*@START_MENU_TOKEN@*/.all, 5.0/*@END_MENU_TOKEN@*/)
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("taptic! (iphone)")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
