//
//  haptaptickApp.swift
//  haptaptick
//
//  Created by Joshua Taylor on 4/19/24.
//

import SwiftUI

@main
struct haptaptickApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
