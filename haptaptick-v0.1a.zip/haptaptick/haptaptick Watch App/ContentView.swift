//
//  ContentView.swift
//  haptaptick Watch App
//
//  Created by Joshua Taylor on 4/19/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Spacer(minLength: 4)
            Text("taptic! (watch)")
            Spacer(minLength: 20)
            Button(action: taptest) {
                Text("taptest")
            }
            Spacer(minLength: 40)
        }
        .padding()
        .scrollDisabled(false)
    }
}

func taptest() {
    WKInterfaceDevice.current().play(.click)
    usleep(103113)
    WKInterfaceDevice.current().play(.click)
    usleep(205225)
    WKInterfaceDevice.current().play(.click)
    usleep(103113)
    WKInterfaceDevice.current().play(.click)
}

#Preview {
    ContentView()
}
