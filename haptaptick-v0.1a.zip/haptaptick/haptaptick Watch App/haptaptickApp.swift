//
//  haptaptickApp.swift
//  haptaptick Watch App
//
//  Created by Joshua Taylor on 4/19/24.
//

import SwiftUI

@main
struct haptaptick_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
